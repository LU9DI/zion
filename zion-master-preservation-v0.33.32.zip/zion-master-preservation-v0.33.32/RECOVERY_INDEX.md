# Zion master preservation bundle — v0.33.32

Includes the v0.33.32 source tree, release ZIP and SHA-256, all v0.33 release ZIPs and adjacent checksum files found in the working directory, available v0.33 audit reports, and all `zion_*.log` test/demo logs available at packaging time.

`SHA256SUMS.txt` records every file in this directory tree except itself. The master ZIP has a separate adjacent SHA-256 file.

This is an artifact preservation backup, not a copy of deleted chat transcripts. It preserves only surviving files. The connected GitHub repository `LU9DI/zion` was inspected and reported empty; no push/deploy is claimed.
